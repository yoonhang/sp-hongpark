package com.example.firstproject.ioc;

public class Chicken extends Ingredient{

    public Chicken(String name) {
        super(name);
    }
}
